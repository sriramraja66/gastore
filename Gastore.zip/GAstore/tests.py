from datetime import datetime

print(datetime.now())