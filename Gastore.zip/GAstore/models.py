from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse


class AddGAccounts(models.Model):

    def get_absolute_url(self):
        return reverse('detail',kwargs={'id':self.id})

    def __str__(self):
        return "{} {} {}".format(self.name,self.game_name,self.game_id)

    title = models.CharField(max_length=60,blank=True,default='')
    user_name = models.ForeignKey(User,on_delete=models.CASCADE,default=1)
    name      = models.CharField(max_length=50)
    game_name = models.CharField(max_length=50)
    game_id   = models.CharField(max_length=60)
    in_game_name = models.CharField(max_length=50)
    game_lev  = models.IntegerField()
    about_account = models.TextField(max_length=500)
    special = models.CharField(max_length=100)
    price = models.IntegerField()
    game_login = models.CharField(max_length=40)
    is_sold = models.BooleanField(default=False)

    number = models.IntegerField()
    com_language = models.CharField(max_length=10)
    game_img = models.URLField()
    game_vid = models.URLField()
    your_profile = models.URLField()
    payment = models.CharField(max_length=20)
    likes = models.ManyToManyField(User,blank=True,related_name='Like')
    date_added = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    def Total_likes(self):
        return self.likes.count()

    class Meta:
        ordering = ['-id']


class FeedBack(models.Model):

    def __str__(self):
        return "{} {} {}".format(self.user,self.email,self.name)

    user = models.ForeignKey(User,on_delete=models.CASCADE,default=1)
    name = models.CharField(max_length=50)
    email = models.EmailField()
    sub = models.CharField(max_length=60,default='')
    message = models.TextField(max_length=400)
    date_added = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    class Meta:
        ordering = ['-id']

class Comment(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    post = models.ForeignKey(AddGAccounts,on_delete=models.CASCADE,related_name='comments')
    comment = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    
    def __str__(self):
        return "{} -{} of {}".format(self.user,self.post.title,str(self.user.username))

    class Meta:
        ordering = ['-id']

class Order(models.Model):
    buyer_user = models.ForeignKey(User,on_delete=models.CASCADE,related_name ="buyer")
    owner = models.ForeignKey(User,on_delete=models.CASCADE ,related_name='owner' )
    post = models.ForeignKey(AddGAccounts,on_delete=models.CASCADE,related_name ='post')

    msg = models.CharField(max_length=100,blank=True)

    payment = models.CharField(max_length=40)
    date_added = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    email = models.EmailField()
    number = models.IntegerField(null=False)
    agree = models.BooleanField(default=False)

    def __str__(self):
        return "{} to {}".format(self.owner.username,self.buyer_user.username)


    class Meta:
        ordering = ['-id']
