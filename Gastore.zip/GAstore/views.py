from django.shortcuts import render,redirect
from .models import AddGAccounts,FeedBack,Comment, Order
from django.urls import reverse
from embeddify import Embedder
from bs4 import BeautifulSoup
from django.urls import reverse_lazy
from  .forms import UserForm
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.contrib import messages

def emb(url):
    em = Embedder()
    res = em(url)
    soup = BeautifulSoup(res,"html.parser").find_all('iframe')

    res = soup[0].get('src')

    return res

# Index
def index(request):
    datas = AddGAccounts.objects.all()
    context = {
        'contact':True,
        'ceninfo':True,
        "datas":datas,

    }
    messages.success(request, request.user)
    if request.method == 'POST':
        search = request.POST.get('search')
        if search !='' and search is not None:
            print (search)
            context['datas'] = datas.filter(game_name__icontains=search)
            return HttpResponseRedirect(reverse('index'))

    return render(request,'pages/index.html',context)

@login_required
def detail(request,id):
    data = AddGAccounts.objects.get(id=id)

    url = emb(data.game_vid)
    if data.likes.filter(id=request.user.id).exists():
        is_liked = False
    else:
        is_liked = True

    T_likes = data.Total_likes()

    if request.user == data.user_name:
        is_user = False
    else:
        is_user = True
    context = {
        'data':data,
        "url":url,
        'likes':T_likes,
        'is_liked':is_liked,
        'is_user':is_user,
        'T_comments':len(data.comments.all()),
        }

    return render(request,'pages/detail.html',context)

@login_required
def Add_Account(request):
    if request.method == 'POST':
        user = request.user
        name = request.POST.get('name','')
        game_name  = request.POST.get('gamename','')
        ingame_name  = request.POST.get('ingame_name','')
        game_id = request.POST.get('game_id','')
        game_lev = request.POST.get('game_lev','')
        about = request.POST.get('about','')
        spec = request.POST.get('special','')
        log_in = request.POST.get('game_log','')
        price= request.POST.get('price','')
        number = request.POST.get('number','')
        lang= request.POST.get('com_language','')
        vid_l= request.POST.get('game_vid','')
        img_l= request.POST.get('game_img','')
        pro_l= request.POST.get('your_profile','')
        pay= request.POST.get('payment','')
        title = request.POST.get('title',spec)
        obj = AddGAccounts(title=title,user_name=user,name=name,game_name=game_name,game_id=game_id,in_game_name=ingame_name,game_lev=game_lev,
        about_account=about,special=spec,price=price,game_login=log_in,number=number,com_language=lang,game_img=img_l,
        game_vid=vid_l,your_profile=pro_l,payment=pay)

        obj.save()
        return redirect('index')
    return render(request,'pages/AddAccount.html')

@login_required
def update_Account(request,id):
    account = AddGAccounts.objects.get(id=id)
    if request.method == 'POST':
        user = request.user
        name = request.POST.get('name','')
        game_name  = request.POST.get('gamename','')
        ingame_name  = request.POST.get('ingame_name','')
        game_id = request.POST.get('game_id','')
        game_lev = request.POST.get('game_lev','')
        about = request.POST.get('about','')
        spec = request.POST.get('special','')
        log_in = request.POST.get('game_log','')
        price= request.POST.get('price','')
        number = request.POST.get('number','')
        lang= request.POST.get('com_language','')
        vid_l= request.POST.get('game_vid','')
        img_l= request.POST.get('game_img','')
        pro_l= request.POST.get('your_profile','')
        title = request.POST.get('title',spec)

        AddGAccounts.objects.filter(id=id).update(title=title,user_name=user,name=name,game_name=game_name,game_id=game_id,in_game_name=ingame_name,game_lev=game_lev,
        about_account=about,special=spec,price=price,game_login=log_in,number=number,com_language=lang,game_img=img_l,
        game_vid=vid_l,your_profile=pro_l)

        return redirect(account.get_absolute_url())


    return render(request,'pages/updateAccount.html',{'acc':account})

@login_required
def del_Account(request,id):
    account = AddGAccounts.objects.get(id=id)
    account.delete()
    return redirect('dash')


def registerAccount(request):
    form = UserForm()

    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Your Account Created!!")
            return redirect("login")


    return render(request,'auth/register.html',{'form':form})


def logoutAccount(request):
    logout(request)
    return redirect("login")


@login_required
def feedback(request):
    if request.method == 'POST':
        username=request.user
        name=request.POST.get('name','')
        email=request.POST.get('email','')
        sub = request.POST.get('subject','')
        msg=request.POST.get('message','')

        feed = FeedBack(user=username,name=name,email=email,sub=sub,message=msg)

        feed.save()

    return redirect('index')

def about(request):
    return render(request,'pages/about.html')

@login_required
def Dashboard(request):

    datas = AddGAccounts.objects.all()
    posted_accounts = AddGAccounts.objects.filter(user_name = request.user.id)

    buyer = Order.objects.filter(buyer_user=request.user)
    owner = Order.objects.filter(owner=request.user)

    liked_post = datas.filter(likes=request.user)
    contex = {
        'accounts': posted_accounts,
        'liked_posts': liked_post,
        'buyer':buyer,
        'owner':owner,
    }
    return render(request,'pages/Dashboard.html',contex)


@login_required
def orderAccount(request,id):
    account = AddGAccounts.objects.get(id=id)

    if request.method == 'POST':
        owner = account.user_name
        buyer = request.user
        email = request.user.email
        post = account
        payment = request.POST.get('payment','')
        number = request.POST.get('number',"")
        msg = request.POST.get('msg')
        agree = request.POST.get('agree')
        if agree == 'on':
            agree = True
        else:
            agree = False
        print("Geted")

        od = Order(owner=owner,buyer_user=buyer,email=email,post=post,number=number,agree=agree,payment=payment,msg=msg)
        od.save()
        return redirect(account.get_absolute_url())
    context = {
        'post':account,
    }
    return render(request,'pages/order.html',context)

@login_required
def delOrder(request,id):
    if request.method=='POST':
        order = Order.objects.get(id=id)
        order.delete()
    return redirect('dash')

@login_required
def like_post(request):
    post = get_object_or_404(AddGAccounts,id=request.POST.get('post_id'))
    is_liked= False
    if post.likes.filter(id=request.user.id).exists():
        post.likes.remove(request.user)
        is_liked=False
    else:
        post.likes.add(request.user)
        is_liked=True
    return HttpResponseRedirect(post.get_absolute_url())

@login_required
def post_comments(request,id):
    if request.method == 'POST':
        user = request.user
        post =  AddGAccounts.objects.get(id=id)
        comment = request.POST.get('cmt','')
        cmt = Comment(user=user,comment=comment,post=post)
        cmt.save()

    return HttpResponseRedirect(post.get_absolute_url())
