from django.contrib import admin

from .models import AddGAccounts,FeedBack,Comment, Order

admin.site.register(AddGAccounts)

admin.site.register(FeedBack)


admin.site.register(Comment)


admin.site.register(Order)