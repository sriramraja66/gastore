from django.apps import AppConfig


class GastoreConfig(AppConfig):
    name = 'GAstore'
