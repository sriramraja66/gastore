from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

# path("Account/delete/order/<int:id>",views.delOrder,name='delOrder'),
urlpatterns = [
    path('',views.index,name='index'),
    path('FeeadBack/contact/GAStore',views.feedback,name='feedback'),

    path('detail/<int:id>', views.detail,name='detail'),
    path('addacc/',views.Add_Account,name = 'addacc'),
    path('update/<int:id>',views.update_Account,name='update'),
    path('delete/account/<int:id>',views.del_Account,name='delete'),
    path('user/dashboard/',views.Dashboard,name='dash'),
    path('about/',views.about,name='about'),

    path('Account/Buy/OrederAccount/<int:id>',views.orderAccount,name='order'),
    path('account/delete/orderAccount/<int:id>',views.delOrder,name='delOrder'),

    path("like/post",views.like_post,name='like_post'),
    path("comments/post/user/<int:id>",views.post_comments,name='comment_post'),

    path('auth/register',views.registerAccount,name='register'),
    path('auth/login',auth_views.LoginView.as_view(template_name='auth/login.html'),name='login'),
    path('auth/logout',views.logoutAccount,name='logout'),
]
